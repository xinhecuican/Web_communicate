package Interface;

public interface IDownload_listener
{
    void On_len_change(int now_len);
}
