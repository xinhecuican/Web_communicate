package Interface;

public interface IComponent
{
    void after_initialize();
}
