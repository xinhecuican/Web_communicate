package Main_window.Data;

/**
 * @author: 李子麟
 * @date: 2021/4/5 14:03
 **/
public class Heart_beat_info
{
    public int my_id;
    public Heart_beat_info(int id)
    {
        my_id = id;
    }
}
